﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace ApiFramework
{
    public class HttpUtil
    {
        public static void Register(HttpContext context)
        {
      
            var handle = new HttpHandler();
            context.RemapHandler(handle);
        }
        public static T Deserialize<T>(T entity)
        {
            var stream = HttpContext.Current.Request.InputStream;
            StreamReader reader = new StreamReader(stream);
            string requestContent = reader.ReadToEnd();
            T obj = JsonConvert.DeserializeAnonymousType(requestContent, entity);
            return obj;

        }
    }
}
