﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ApiFramework.Filter
{
    public class FilterContextManage
    {
        public static void Set(FilterContext context)
        {
            CallContext.SetData("filterContext", context);

        }
        public static FilterContext Get()
        {
            var context = CallContext.GetData("filterContext") as FilterContext;
            return context;
        }
    }
}
