﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApiFramework
{
    [AttributeUsage(AttributeTargets.Class, AllowMultiple = false, Inherited = false)]
    public abstract class BeforeAttributeFilter : Attribute 
    {
        public abstract void Process(FilterContext context);
        
        protected bool Valid { set; get; }
        public BeforeAttributeFilter(bool valid)
        {
            Valid = valid;
        }
    }
}
