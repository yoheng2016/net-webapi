﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace ApiFramework
{
    public class FilterContext
    {
        public HttpRequest Request { set; get; }
        public HttpResponse Response { set; get; }
        public bool BeforePass { set; get; }
        public object BeforeResult { set; get; }
        public object HandleResult { set; get; }
     

    }
}
