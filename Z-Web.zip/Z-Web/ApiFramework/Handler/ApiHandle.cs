﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace ApiFramework
{
    public abstract class ApiHandle
    {
        public abstract void Execute(HttpRequest req, HttpResponse res);
    }
}
