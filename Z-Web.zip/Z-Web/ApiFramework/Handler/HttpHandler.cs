﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace ApiFramework
{
    public class HttpHandler : IHttpHandler
    {

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }

        public void ProcessRequest(HttpContext context)
        {
            this.Process(context);
        }
        private UrlAnalysis urlAnalysis;
        /// <summary>
        /// 请求处理入口
        /// </summary>
        /// <param name="context"></param>
        private void Process(HttpContext context)
        {
            urlAnalysis = this.AnalysisUrl(context);
            if (string.IsNullOrEmpty(urlAnalysis.Domain) || string.IsNullOrEmpty(urlAnalysis.Method))
            {
                return;
            }
            var filterContext = this.CreateFilterContext(context.Request, context.Response);

            this.Before(filterContext);
            if (filterContext.BeforePass)
            {
                var handle = this.CreateHanle();
                handle.Execute(context.Request, context.Response);
            }
            this.After(filterContext);
        }
        
        private FilterContext CreateFilterContext(HttpRequest req, HttpResponse res)
        {
            FilterContext context = new FilterContext();
            context.Request = req;
            context.Response = res;
            return context;
        }
        /// <summary>
        /// 解析URL
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        private UrlAnalysis AnalysisUrl(HttpContext context)
        {
            var url = context.Request.Url.AbsoluteUri;
            UrlAnalysis analysis = new UrlAnalysis(url);
            analysis.Analysis();
            return analysis;
        }
        private Type GetExcuteType()
        {
            var appName = ConfigurationManager.AppSettings[urlAnalysis.Domain].ToString();
            Assembly assembly = Assembly.LoadFrom(AppDomain.CurrentDomain.BaseDirectory + "bin\\" + appName + ".dll");
            Type type = assembly.GetType(appName + "." + urlAnalysis.Method);
            return type;
        }
        private void Before(FilterContext context)
        {
            Type type = this.GetExcuteType();
            var before = type.GetCustomAttribute<BeforeAttributeFilter>();
            if (before.IsNull())
            {
                return;
            }
            before.Process(context);
        }
        private void After(FilterContext context)
        {
            Type type = this.GetExcuteType();
            var after = type.GetCustomAttribute<AfterAttributeFilter>();
            if (after.IsNull())
            {
                return;
            }
            after.Process(context);
        }
        /// <summary>
        /// 创建具体执行对象
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        private ApiHandle CreateHanle()
        {
            Type type = this.GetExcuteType();
            ApiHandle handle = Activator.CreateInstance(type) as ApiHandle;
            return handle;
        }
    }
    /// <summary>
    /// url解析类
    /// </summary>
    public class UrlAnalysis
    {
        string _url = string.Empty;
        public UrlAnalysis(string url)
        {
            _url = url;
        }
        public string Domain { set; get; }
        public string Method { set; get; }
        public void Analysis()
        {
            string[] arr = _url.Split('/');
            if (arr.Length < 5)
            {
                return;
            }
            string domain = arr[3];
            string method = arr[4];
            this.Domain = domain;
            this.Method = method;
        }
    }
}
