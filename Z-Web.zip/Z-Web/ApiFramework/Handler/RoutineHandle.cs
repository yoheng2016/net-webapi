﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace ApiFramework
{
    /// <summary>
    /// 
    /// </summary>
    public abstract class RoutineHandle : ApiHandle
    {

        public override void Execute(HttpRequest req, HttpResponse res)
        {
            var obj = this.Execute();
            string str = JsonConvert.SerializeObject(obj);
            res.Write(str);
        }
        public abstract object Execute();

    }
}
