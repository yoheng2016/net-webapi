﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Z_WebFramework.Host;

namespace Z_WebFramework
{
    public class HostBuilder
    {
        public WebHost UseStartup<T>() where T : class,new()
        {
            return null;
        }


    }
}
