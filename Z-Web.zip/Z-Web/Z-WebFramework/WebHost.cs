﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Z_WebFramework.Host
{
    public class WebHost
    {
        public void Run()
        {

        }
        public static HostBuilder CreateDefaultBuilder(string[] args)
        {
            return null;
        }
    }
}
