﻿using ApiFramework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using Tenement.DB;

namespace Tenement
{
    public class GetUserList : ApiHandle
    {


        public override void Execute(HttpRequest req, HttpResponse res)
        {
            TenementDbContext db = new TenementDbContext();
            var list = db.T_Sys_User.ToList();
            req.ContentType = "application/json";
            res.Write("{'name':'zhaoheng'}");
        }
    }
}
