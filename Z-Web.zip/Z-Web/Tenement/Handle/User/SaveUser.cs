﻿using ApiFramework;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tenement
{
    public class SaveUser : RoutineHandle
    {

        public override object Execute()
        {
            var param = HttpUtil.Deserialize(new
              {
                  Name="zh",
                  Age=19
              });
            return param;
          
             
        }
    }
}
