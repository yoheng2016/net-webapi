﻿using ApiFramework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tenement
{
    [LoginAttributeFilter(true)]
    public class Login : RoutineHandle
    {
        public override object Execute()
        {
            return new { Msg="登录成功！" };
        }
    }
}
