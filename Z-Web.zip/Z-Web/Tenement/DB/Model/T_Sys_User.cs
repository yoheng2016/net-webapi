﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tenement.Model
{
   public class T_Sys_User
    {
        [Key]
        public string ID { set; get; }
        public string Name { set; get; }
        public string Code { set; get; }

    }
}
