﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.ModelConfiguration.Conventions;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Tenement.Model;

namespace Tenement.DB
{
    public class TenementDbContext : DbContext
    {
        public TenementDbContext() : base("name=conn")
        { 
        
        }
        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            modelBuilder.Conventions.Remove<PluralizingTableNameConvention>();
        }
        public DbSet<T_Sys_User> T_Sys_User { set; get; }
    }
}
