﻿using ApiFramework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tenement
{
    public class LoginAttributeFilter : BeforeAttributeFilter
    {
        public LoginAttributeFilter(bool valid):base(valid)
        { 
        
        }
        public override void Process(FilterContext context)
        {
            if (!this.Valid)
            {
                return;
            }
            //context.Response.Write("YYYYYYYYYYYYUU--");
            context.BeforePass = false;
            context.BeforeResult = new {Name="zhggggggggggggg", };

        }
    }
}
