﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Z_WebFramework;
using Z_WebFramework.Host;

namespace Z_Web
{
    class Program
    {
        static void Main(string[] args)
        {
            //https://www.cnblogs.com/qigang/p/3918270.html
            WebHost.CreateDefaultBuilder(args).UseStartup<Startup>().Run();

        }


    }
}
